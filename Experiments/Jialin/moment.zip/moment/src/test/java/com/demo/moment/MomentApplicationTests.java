package com.demo.moment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MomentApplicationTests {

	@Test
	void contextLoads() {
	}

}
