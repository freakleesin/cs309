package com.demo.moment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MomentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MomentApplication.class, args);
	}

}
